<?php

namespace App\Http\Middleware;

use App\Services\Printing\AgentKey;
use App\Support\Settings;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Symfony\Component\HttpFoundation\Response;

/** Only the shop PC print program (holding the agent key) may collect print jobs. */
class AuthenticateAgent
{
    public function __construct(private readonly Settings $settings) {}

    public function handle(Request $request, Closure $next): Response
    {
        $token = (string) $request->bearerToken();
        $stored = (string) $this->settings->get('agent_key_hash', '');
        if ($token === '' || ! AgentKey::valid($token, $stored)) {
            return response()->json(['message' => 'The print program key is not valid.'], 401);
        }
        Cache::put('agent.last_seen', now()->toIso8601String(), now()->addDays(2));

        return $next($request);
    }
}
