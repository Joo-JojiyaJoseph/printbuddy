<?php

namespace App\Services\Printing;

use App\Models\Document;
use App\Models\PrintJob;
use App\Models\PrintOrder;
use App\Services\Audit\AuditLogger;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;

/**
 * Prints a PAID order. Only a server-verified payment ever reaches here (EloquentPaymentStore dispatches it),
 * and the job row guarantees an order is never sent to the printer twice.
 */
class PrintJobService
{
    public function __construct(
        private readonly PrintFileComposer $composer,
        private readonly PrinterDriver $driver,
        private readonly AuditLogger $audit,
    ) {}

    /** Create the job row (idempotent). Called inside the payment transaction. */
    public function enqueue(PrintOrder $order): PrintJob
    {
        return PrintJob::query()->firstOrCreate(['print_order_id' => $order->id], ['status' => PrintJob::QUEUED, 'driver' => $this->driver->name()]);
    }

    /**
     * @param  bool  $final  true on the last attempt: a retryable failure then becomes `failed` instead of being re-queued.
     *
     * @throws PrintException when a retry should happen
     */
    public function print(string $orderId, bool $final = true): void
    {
        $job = DB::transaction(function () use ($orderId) {
            $order = PrintOrder::query()->whereKey($orderId)->lockForUpdate()->first();
            if ($order === null || $order->status !== 'paid') {
                return null; // never print an unpaid order
            }
            $job = PrintJob::query()->where('print_order_id', $order->id)->lockForUpdate()->first() ?? $this->enqueue($order);
            if ($job->status === PrintJob::SENT) {
                return null;
            }
            if ($job->status === PrintJob::WAITING) {
                return null; // already prepared and waiting for the shop PC
            }
            if ($job->status === PrintJob::SENDING) {
                // A worker died between handing the file over and recording it: we can't tell whether it printed.
                // Reprinting could double-print, so hand it to staff.
                $job->forceFill(['status' => PrintJob::FAILED, 'failure_reason' => 'Print status unknown — check the printer before retrying.'])->save();
                $this->audit->log('print.unknown', $job, ['order' => $order->reference]);

                return null;
            }
            $job->forceFill(['status' => PrintJob::PREPARING, 'attempts' => $job->attempts + 1, 'driver' => $this->driver->name(), 'failure_reason' => null])->save();

            return [$job, $order];
        });
        if ($job === null) {
            return;
        }
        [$job, $order] = $job;

        $tmp = null;
        try {
            if (! $this->driver->available()) {
                throw new PrintException('The printer is not set up on this machine.', retryable: false);
            }
            if ($this->driver instanceof DeferredPrinter && ($need = $this->renderNeeded($order)) !== null) {
                $this->requestRender($job, $order, $need); // the shop PC renders the pages (its own Poppler); we compose when they arrive

                return;
            }
            [$file, $tmp, $pages, $direct] = $this->prepareFile($order);
            $settings = $order->print_settings;
            if ($this->driver instanceof DeferredPrinter) {
                $this->handOverToAgent($job, $order, $file, $pages);

                return;
            }
            $job->forceFill(['status' => PrintJob::SENDING, 'pages' => $pages])->save();
            $jobId = $this->driver->send($file, [
                'reference' => $order->reference,
                'title' => 'Taprint '.$order->reference,
                'copies' => max(1, (int) ($settings['copies'] ?? 1)),
                'color' => ($settings['color_mode'] ?? 'bw') === 'color',
                'duplex' => (bool) ($settings['duplex'] ?? false),
                'landscape' => ($settings['orientation'] ?? 'portrait') === 'landscape',
                'paper' => (string) ($settings['paper_size'] ?? 'A4'),
                'direct' => $direct,
            ]);
            $job->forceFill(['status' => PrintJob::SENT, 'printer_job_id' => $jobId ? mb_substr($jobId, 0, 100) : null, 'sent_at' => now()])->save();
            $this->scheduleErase($order);
            $this->audit->log('print.sent', $job, ['order' => $order->reference, 'pages' => $pages, 'driver' => $this->driver->name()]);
        } catch (PrintException $e) {
            $this->fail($job, $order, $e->getMessage(), $e->retryable && ! $final);
            if ($e->retryable && ! $final) {
                throw $e;
            }
        } catch (\Throwable $e) {
            Log::error('Print job crashed', ['order' => $order->reference, 'error' => $e->getMessage()]);
            $this->fail($job, $order, 'Something went wrong while printing.', false);
        } finally {
            if ($tmp !== null && is_file($tmp)) {
                @unlink($tmp);
            }
        }
    }

    /** Keep the prepared PDF in private storage until the shop PC collects it. */
    private function handOverToAgent(PrintJob $job, PrintOrder $order, string $file, int $pages): void
    {
        $rel = 'agent-spool/'.$job->id.'.pdf';
        $in = fopen($file, 'rb');
        if ($in === false || ! Storage::disk(config('printbuddy.documents_disk'))->put($rel, $in)) {
            throw new PrintException('The print file could not be stored for the shop computer.', retryable: true);
        }
        fclose($in);
        $job->forceFill(['status' => PrintJob::WAITING, 'pages' => $pages, 'agent_file' => $rel, 'agent_meta' => $this->agentMeta($order, 'print')])->save();
        $this->audit->log('print.waiting_for_agent', $job, ['order' => $order->reference, 'pages' => $pages]);
    }

    /** @return array<string,mixed> what the shop PC needs to print (or to render) this order */
    private function agentMeta(PrintOrder $order, string $phase, array $extra = []): array
    {
        $s = (array) $order->print_settings;

        return [
            'phase' => $phase,
            'reference' => $order->reference,
            'title' => 'Taprint '.$order->reference,
            'copies' => max(1, (int) ($s['copies'] ?? 1)),
            'color' => ($s['color_mode'] ?? 'bw') === 'color',
            'duplex' => (bool) ($s['duplex'] ?? false),
            'landscape' => ($s['orientation'] ?? 'portrait') === 'landscape',
            'paper' => (string) ($s['paper_size'] ?? 'A4'),
        ] + $extra;
    }

    /** @return array{pages:list<int>,gray:bool,dpi:int}|null pages the shop PC must render, or null when none are needed */
    private function renderNeeded(PrintOrder $order): ?array
    {
        $doc = Document::query()->find($order->document_id);
        if ($doc === null || $doc->deleted_at !== null) {
            throw new PrintException('The document is no longer available.');
        }
        $settings = (array) $order->print_settings;
        if (in_array($doc->kind, ['jpg', 'png'], true) || PrintFileComposer::isDirect($settings, (string) $doc->kind)) {
            return null;
        }

        return $this->composer->plan($settings, ['kind' => 'pdf', 'page_count' => (int) $doc->page_count]);
    }

    private function requestRender(PrintJob $job, PrintOrder $order, array $need): void
    {
        $this->discardSpool($job);
        $job->forceFill(['status' => PrintJob::WAITING, 'agent_file' => null, 'agent_meta' => $this->agentMeta($order, 'render', ['render_pages' => $need['pages'], 'dpi' => $need['dpi'], 'gray' => $need['gray']])])->save();
        $this->audit->log('print.render_requested', $job, ['order' => $order->reference, 'pages' => count($need['pages'])]);
    }

    /** The source PDF the shop PC renders from (private storage path). */
    public function renderSource(PrintJob $job): ?string
    {
        $order = PrintOrder::query()->find($job->print_order_id);
        $doc = $order ? Document::query()->find($order->document_id) : null;
        if ($doc === null || $doc->deleted_at !== null) {
            return null;
        }
        $path = Storage::disk(config('printbuddy.documents_disk'))->path((string) ($doc->preview_path ?: $doc->storage_path));

        return is_file($path) ? $path : null;
    }

    /** The shop PC finished rendering: compose the final file from its pictures and make it ready to print. */
    public function renderFinished(PrintJob $job): void
    {
        $order = PrintOrder::query()->find($job->print_order_id);
        $disk = Storage::disk(config('printbuddy.documents_disk'));
        $dir = 'agent-spool/'.$job->id;
        $tmp = null;
        try {
            if ($order === null) {
                throw new PrintException('The order is no longer available.');
            }
            $need = (array) ($job->agent_meta ?? []);
            $rasters = [];
            foreach ((array) ($need['render_pages'] ?? []) as $n) {
                $path = $disk->path($dir.'/p'.(int) $n.'.jpg');
                $size = is_file($path) ? @getimagesize($path) : false;
                if ($size === false) {
                    throw new PrintException('The shop computer did not send every page.');
                }
                $rasters[(int) $n] = [$path, $size[0], $size[1]];
            }
            $doc = Document::query()->find($order->document_id);
            $tmp = tempnam(sys_get_temp_dir(), 'pbprint').'.pdf';
            $out = $this->composer->compose((array) $order->print_settings, ['kind' => 'pdf', 'page_count' => (int) ($doc?->page_count ?? 1)], $tmp, $rasters);
            $this->handOverToAgent($job, $order, $tmp, (int) $out['pages']);
        } catch (PrintException $e) {
            $this->fail($job, $order ?? new PrintOrder(), $e->getMessage(), false);
        } catch (\Throwable $e) {
            Log::error('Render finish crashed', ['job' => $job->id, 'error' => $e->getMessage()]);
            $this->fail($job, $order ?? new PrintOrder(), 'Something went wrong while preparing the pages.', false);
        } finally {
            if ($tmp !== null && is_file($tmp)) {
                @unlink($tmp);
            }
            $disk->deleteDirectory($dir); // the page pictures are no longer needed
        }
    }

    /** The shop PC reports back. Success: sent. Failure: needs staff (we cannot tell whether paper came out). */
    public function agentFinished(PrintJob $job, bool $ok, ?string $printerJobId, ?string $message): void
    {
        $order = PrintOrder::query()->find($job->print_order_id);
        if ($ok) {
            $job->forceFill(['status' => PrintJob::SENT, 'printer_job_id' => $printerJobId ? mb_substr($printerJobId, 0, 100) : null, 'sent_at' => now(), 'failure_reason' => null])->save();
            if ($order !== null) {
                $this->scheduleErase($order);
            }
            $this->audit->log('print.sent', $job, ['order' => $order?->reference, 'pages' => $job->pages, 'driver' => 'agent']);
        } else {
            $reason = AgentKey::cleanMessage($message);
            $job->forceFill(['status' => PrintJob::FAILED, 'failure_reason' => 'The shop printer reported a problem'.($reason !== '' ? ': '.$reason : '.')])->save();
            $this->audit->log('print.failed', $job, ['order' => $order?->reference, 'reason' => $reason]);
        }
        $this->discardSpool($job);
    }

    public function discardSpool(PrintJob $job): void
    {
        Storage::disk(config('printbuddy.documents_disk'))->deleteDirectory('agent-spool/'.$job->id);
        if ($job->agent_file) {
            Storage::disk(config('printbuddy.documents_disk'))->delete($job->agent_file);
            $job->forceFill(['agent_file' => null])->save();
        }
    }

    /** Privacy: shorten the retention of this session's files so they disappear shortly after a successful print. */
    private function scheduleErase(PrintOrder $order): void
    {
        $minutes = (int) config('printbuddy.printing.erase_after_minutes', 10);
        if ($minutes <= 0) {
            return;
        }
        Document::query()->where('qr_session_id', $order->qr_session_id)->whereNull('deleted_at')
            ->where(fn ($q) => $q->whereNull('delete_after')->orWhere('delete_after', '>', now()->addMinutes($minutes)))
            ->update(['delete_after' => now()->addMinutes($minutes)]);
    }

    /** Staff retry for a failed job. Resets it to queued; the caller dispatches PrintOrderJob. */
    public function reset(PrintOrder $order, ?int $userId = null): PrintJob
    {
        if ($order->status !== 'paid') {
            throw new \InvalidArgumentException('Only paid orders can be printed.');
        }
        $job = $this->enqueue($order);
        if ($job->status === PrintJob::SENT) {
            throw new \InvalidArgumentException('This order has already been sent to the printer.');
        }
        $this->discardSpool($job);
        $job->forceFill(['status' => PrintJob::QUEUED, 'failure_reason' => null])->save();
        $this->audit->log('print.retry', $job, ['order' => $order->reference], $userId);

        return $job;
    }

    private function fail(PrintJob $job, PrintOrder $order, string $reason, bool $willRetry): void
    {
        $job->forceFill(['status' => $willRetry ? PrintJob::QUEUED : PrintJob::FAILED, 'failure_reason' => mb_substr($reason, 0, 250)])->save();
        if (! $willRetry) {
            $this->discardSpool($job);
            $this->audit->log('print.failed', $job, ['order' => $order->reference, 'reason' => $reason]);
        }
    }

    /** @return array{0:string,1:?string,2:int,3:bool} file to send, temp file to delete, pages, direct */
    private function prepareFile(PrintOrder $order): array
    {
        $doc = Document::query()->find($order->document_id);
        if ($doc === null || $doc->deleted_at !== null) {
            throw new PrintException('The document is no longer available.');
        }
        $disk = Storage::disk(config('printbuddy.documents_disk'));
        $settings = (array) $order->print_settings;
        $isImage = in_array($doc->kind, ['jpg', 'png'], true);

        if (PrintFileComposer::isDirect($settings, (string) $doc->kind)) {
            $path = $disk->path((string) ($doc->preview_path ?: $doc->storage_path));
            if (! is_file($path)) {
                throw new PrintException('The document file is missing.');
            }

            return [$path, null, (int) $doc->page_count, true];
        }
        if (! $isImage && ! $this->composer->available()) {
            throw new PrintException('Page preparation (Poppler) is not installed on this machine.');
        }

        if ($isImage) {
            $ids = collect($settings['edits']['sheet']['images'] ?? [])->pluck('document_id')->push($doc->id)->unique()->all();
            $imageDocs = Document::query()->whereIn('id', $ids)->where('qr_session_id', $order->qr_session_id)->whereNull('deleted_at')->get();
            $paths = [];
            foreach ($imageDocs as $d) {
                if (in_array($d->kind, ['jpg', 'png'], true)) {
                    $paths[$d->id] = ['path' => $disk->path($d->storage_path), 'kind' => $d->kind];
                }
            }
            $source = ['kind' => $doc->kind, 'id' => $doc->id, 'image_paths' => $paths];
        } else {
            $source = ['kind' => 'pdf', 'path' => $disk->path((string) ($doc->preview_path ?: $doc->storage_path)), 'page_count' => (int) $doc->page_count];
        }

        $tmp = tempnam(sys_get_temp_dir(), 'pbprint').'.pdf';
        $out = $this->composer->compose($settings, $source, $tmp);

        return [$tmp, $tmp, $out['pages'], false];
    }
}
